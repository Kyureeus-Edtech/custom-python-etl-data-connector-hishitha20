import os
import requests
import pymongo
from dotenv import load_dotenv
from datetime import datetime

# 1️⃣ Load environment variables from .env
load_dotenv()

OTX_API_KEY = os.getenv("OTX_API_KEY")
MONGODB_URI = os.getenv("MONGODB_URI")
MONGODB_DB = os.getenv("MONGODB_DB")
MONGODB_COLLECTION = os.getenv("MONGODB_COLLECTION")

# 2️⃣ MongoDB connection
client = pymongo.MongoClient(MONGODB_URI)
db = client[MONGODB_DB]
collection = db[MONGODB_COLLECTION]

# 3️⃣ Function to extract data from OTX API
def extract_otx_data(ip_address):
    base_url = "https://otx.alienvault.com"
    endpoint = f"/api/v1/indicators/IPv4/{ip_address}/general"
    url = base_url + endpoint

    headers = {
        "X-OTX-API-KEY": OTX_API_KEY
    }

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        return response.json()
    else:
        print(f"Error fetching data: {response.status_code}, {response.text}")
        return None

# 4️⃣ Transform data (add timestamp for audits)
def transform_data(data):
    if data:
        data["_ingestion_timestamp"] = datetime.utcnow()
    return data

# 5️⃣ Load data into MongoDB
def load_data(data):
    if data:
        collection.insert_one(data)
        print("Data inserted into MongoDB successfully.")

# 6️⃣ Main ETL execution
if __name__ == "__main__":
    test_ip = "8.8.8.8"  # Example IP, replace with any IP you want to check
    raw_data = extract_otx_data(test_ip)
    transformed_data = transform_data(raw_data)
    load_data(transformed_data)
